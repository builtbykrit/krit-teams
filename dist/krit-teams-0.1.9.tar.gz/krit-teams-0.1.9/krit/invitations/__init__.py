default_app_config = "krit.invitations.apps.AppConfig"
